Lint

1. שניתי את החשיבות של ה-Issue בשם Image without contentDescription כך שהפעלת ה-Lint תחזיר Error בשגיאה מסוג זה ולא אזהרה כרגיל.
2. סימנתי בדיקה נוספת שהיא Negative Margins שתבדוק האם נבחרו Margins שלילים ותציג אזהרה אם כן.