package ron.fuelmanager.Activity;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by amit on 1/14/2018.
 */
public class MapActivityTest {


}