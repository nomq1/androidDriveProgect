package ron.fuelmanager;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import android.content.SharedPreferences;

import static org.junit.Assert.*;

/**
 * Created by amit on 1/14/2018.
 */
public class FirebaseHelperTest {
    @Test
    public void uploadData() throws Exception {

    }

    @Test
    public void uploadImage() throws Exception {
    }

}